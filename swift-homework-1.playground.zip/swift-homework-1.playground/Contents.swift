import Foundation

// первое задание
var a:Double = 1
var b:Double = 2
var c:Double = 1
if a != 0 {

let d = (b * b - 4 * a * c)
print("a = ", a, "b = ", b, "c = ", c)
print("Дискриминант равен ", d)

if(d > 0) {
    let x1 = (-b - sqrt(d)) / 2 * a
    let x2 = (-b + sqrt(d)) / 2 * a
    print( "x1 = ", x1, "x2 = ", x2)
} else if(d == 0) {
    let x1 = -b/2*a
    print ("x1 = ", x1)
} else if (d < 0) {
    print ("корней нет")
}
} else {
    print("уравнение не квадратное ")
}


// второе задание
let Katet1:Double = 34
let Katet2:Double = 27
let S = (Katet1 * Katet2)/2
print("Площадь треугольника", Int(S))

let Gipo = sqrt(Katet1 * Katet1 + Katet2 * Katet2)
print("Гипотенуза треугольника", Int(Gipo))

let Perimetr = (Katet1 + Katet2 + Gipo)
print("Периметр треугольника", Int(Perimetr))



// третье задание в двух вариантах
var Years = 1
var SummVklada = 2000
var PercentPerYear = 5

let PercenFirstYear = SummVklada * PercentPerYear/100
let SummFirstYear = SummVklada + PercenFirstYear  // первый год с процентами
let PercentSeconYear = SummFirstYear*PercentPerYear/100
let SummSecondYear = SummFirstYear + PercentSeconYear // второй год с процентами
let PercentThirdYear = SummSecondYear*PercentPerYear/100
let SummThirdYear = SummSecondYear + PercentThirdYear // третий год с процентами
let PercentFourthYear = SummThirdYear*PercentPerYear/100
let SummFourthYear = SummThirdYear + PercentFourthYear // четыертый год с процентами
let PercentFifthYear = SummFourthYear*PercentPerYear/100
let SummFifthYear = SummFourthYear + PercentFifthYear //пятый год с процентами
print("Через пять лет сумма вклада составит", SummFifthYear,"руб")

//или через цикл while

while Years <= 5 {
    let PercenFirstYear = SummVklada * PercentPerYear/100
    let SummFirstYear = SummVklada + PercenFirstYear
    SummVklada = SummFirstYear
    Years+=1
}

print("Сумма вклада за пять лет будет", SummVklada,"руб")
